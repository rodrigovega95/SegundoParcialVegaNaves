
package segundoparcialveganaves;

import Models.Categoria;
import Models.Inventario;
import Models.NaveEspacial;
import java.io.IOException;
import java.util.Comparator;


public class test {

    
    public static void main(String[] args) {
      try {
            Inventario<NaveEspacial> inventario = new Inventario<>();

            inventario.agregar(new NaveEspacial("USS Enterprise", Categoria.EXPLORACION, 1000));
            inventario.agregar(new NaveEspacial("Millennium Falcon", Categoria.CARGA, 6));
            inventario.agregar(new NaveEspacial("TIE Fighter", Categoria.MILITAR, 1));
            inventario.agregar(new NaveEspacial("X-Wing", Categoria.MILITAR, 1));
            inventario.agregar(new NaveEspacial("Discovery One", Categoria.EXPLORACION, 10));
            inventario.agregar(new NaveEspacial("Star Destroyer", Categoria.MILITAR, 5000));
            

            System.out.println("Inventario:"); /*Print del inventario*/
            inventario.listar().forEach(System.out::println);

            System.out.println("\nOrdenado por nombre:"); /*Nombre*/
            inventario.ordenar();
            inventario.listar().forEach(System.out::println);

            System.out.println("\nOrdenado por capacidad:"); /*Capacidad*/
            inventario.ordenar(Comparator.comparingInt(NaveEspacial::getCapacidadTripulacion));
            inventario.listar().forEach(System.out::println);

            System.out.println("\nFiltrado por categoría EXPLORACION:"); /*Filtrar a las categoría EXPLORACIÓN*/
            inventario.filtrar(n -> n.getCategoria() == Categoria.EXPLORACION).forEach(System.out::println);


            inventario.transformar(n -> new NaveEspacial(n.getNombre(), Categoria.MILITAR, n.getCapacidadTripulacion()));
            System.out.println("\nTransformado a MILITAR:"); /*Cambiar a categoría MILITAR*/
            inventario.listar().forEach(System.out::println);

            String archivoBinario = "src/Data/naves.dat"; /*Crear archivos Bin y CSV*/
            String archivoCSV = "src/Data/naves.csv";

            inventario.guardarEnArchivo(archivoBinario); /*Guardar archivos*/
            inventario.guardarEnCSV(archivoCSV, NaveEspacial::toCSV);

            Inventario<NaveEspacial> inventarioCargado = new Inventario<>();
            inventarioCargado.cargarDesdeArchivo(archivoBinario);
            System.out.println("\nCargado desde binario:");
            inventarioCargado.listar().forEach(System.out::println);

            inventarioCargado.cargarDesdeCSV(archivoCSV, NaveEspacial::fromCSV);
            System.out.println("\nCargado desde CSV:");
            inventarioCargado.listar().forEach(System.out::println);
            } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
        
        
        
    }
    
}
