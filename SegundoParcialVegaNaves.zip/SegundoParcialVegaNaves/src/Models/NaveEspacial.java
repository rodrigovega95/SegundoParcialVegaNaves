/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import java.io.Serializable;
/**
 *
 * @author admin
 */
public class NaveEspacial implements Comparable<NaveEspacial>, Serializable, CSVSerializable {
    private String nombre;
    private Categoria categoria;
    private int capacidadTripulacion;

    public NaveEspacial(String nombre, Categoria categoria, int capacidadTripulacion) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.capacidadTripulacion = capacidadTripulacion;
    }

    public String getNombre() {
        return nombre;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public int getCapacidadTripulacion() {
        return capacidadTripulacion;
    }

    @Override
    public String toString() {
        return String.format("NaveEspacial [nombre=%s, categoria=%s, capacidadTripulacion=%d]",
                nombre, categoria, capacidadTripulacion);
    }

    @Override
    public int compareTo(NaveEspacial o) {
        return this.nombre.compareTo(o.nombre);
    }

    @Override
    public String toCSV() {
        return String.join(",", nombre, categoria.name(), String.valueOf(capacidadTripulacion));
    }

    public static NaveEspacial fromCSV(String csv) {
        String[] data = csv.split(",");
        return new NaveEspacial(data[0], Categoria.valueOf(data[1]), Integer.parseInt(data[2]));
    }
}
