/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import java.io.*;
import java.util.*;
import java.util.function.*;

public class Inventario<T> implements Serializable {
    private List<T> elementos;

    public Inventario() {
        this.elementos = new ArrayList<>();
    }

    public void agregar(T elemento) {
        elementos.add(elemento);
    }

    public void eliminar(T elemento) {
        elementos.remove(elemento);
    }

    public List<T> listar() {
        return new ArrayList<>(elementos);
    }

    public void ordenar(Comparator<? super T> comparator) {
        elementos.sort(comparator);
    }

    public void ordenar() {
        if (elementos.get(0) instanceof Comparable) {
            Collections.sort((List<Comparable>) elementos);
        }
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        return elementos.stream().filter(criterio).toList();
    }

    public void transformar(Function<? super T, ? extends T> transformacion) {
        List<T> transformados = new ArrayList<>();
        for (T elemento : elementos) {
            transformados.add(transformacion.apply(elemento));
        }
        elementos = transformados;
    }

    public void guardarEnArchivo(String ruta) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(elementos);
        }
    }

    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            elementos = (List<T>) ois.readObject();
        }
    }

    public void guardarEnCSV(String ruta, Function<? super T, String> toCSV) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ruta))) {
            for (T elemento : elementos) {
                writer.write(toCSV.apply(elemento));
                writer.newLine();
            }
        }
    }

    public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws IOException {
        elementos.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                elementos.add(fromCSV.apply(linea));
            }
        }
    }
}
